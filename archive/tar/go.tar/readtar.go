// readtar.go
package main
