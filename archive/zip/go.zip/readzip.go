// readzip.go
package main
